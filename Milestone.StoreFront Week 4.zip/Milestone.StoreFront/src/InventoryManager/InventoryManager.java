package InventoryManager;

import java.util.ArrayList;
import java.util.List;
import Products.Product;
import java.util.Collections;
import java.io.File;
import java.io.IOException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.jsontype.impl.LaissezFaireSubTypeValidator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonSubTypes.Type;
import com.fasterxml.jackson.annotation.JsonTypeInfo;

public class InventoryManager 
{
	private List<Product> products;
	/**
	 * 
	 */
	public InventoryManager()
	{
		products = new ArrayList<>();
		
	}
	/**
	 * Add a new product to the product list
	 */
	public void addProduct(Product product)
	{
		products.add(product);
	}
	/**
	 * REmove a product from the product list
	 */
	public void removeProduct(Product product)
	{
		products.remove(product);
	}
	/**
	 * get the product list
	 * @return
	 */
	public List<Product> getProducts()
	{
		return products;
	}
	/**
	 * 
	 */
	public void DisplayInventory()
	{
		if (products.isEmpty())
		{
			System.out.println("There is nothing in the shop today! Come back later!");
		}
		else
		{	
			//List<Product> productList = new ArrayList<>(products);
			//Collections.sort(productList);
			//products = productList;
			System.out.println(products);
			System.out.println();
			
		}
	}
	/**
	 * 
	 * @param filename
	 */
	public void LoadFromFile(String filename)
	{
		ObjectMapper objectMapper = new ObjectMapper();
		
	    objectMapper.activateDefaultTyping(
	        objectMapper.getPolymorphicTypeValidator(),
	        ObjectMapper.DefaultTyping.NON_FINAL,
	        JsonTypeInfo.As.PROPERTY);
	    
	    try 
	    {
	        products = objectMapper.readValue(new File(filename),
	            objectMapper.getTypeFactory().constructCollectionType(List.class, Product.class));
	    } catch (IOException e) 
	    {
	        System.out.println("There has been an error reading from the file. The error is: " + e.getMessage());
	    }
	}
	/**
	 * 
	 * @param filename
	 */
	public void SaveToFile(String filename)
	{
		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.activateDefaultTyping(
		        objectMapper.getPolymorphicTypeValidator(),
		        ObjectMapper.DefaultTyping.NON_FINAL,
		        JsonTypeInfo.As.PROPERTY);

		try
		{
			objectMapper.writerWithDefaultPrettyPrinter().writeValue(new File(filename), products);
			//objectMapper.writeValue(new File(filename), products);
		}
		catch(IOException e)
		{
			System.out.println("There has been an error writing to the file.  The error is: " + e.getMessage());
		}
	}
	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) 
	{
	

	}

}
