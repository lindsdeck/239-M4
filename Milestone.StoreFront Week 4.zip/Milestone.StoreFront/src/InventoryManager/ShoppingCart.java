package InventoryManager;

import java.util.ArrayList;
import java.util.List;
import Products.Product;


public class ShoppingCart 
{
	private List<Product> cart;
	/**
	 * 
	 */
	public ShoppingCart()
	{
		cart = new ArrayList<>();
	}
	/**
	 * 
	 * @param product
	 */
	public void addProduct(Product product)
	{

		cart.add(product);
	}
	/**
	 * 
	 * @param product
	 */
	public void removeProduct(Product product)
	{
		cart.remove(product);
	}
	/**
	 * 
	 * @return
	 */
	public List<Product> getCartInventory()
	{
		return cart;
	}
	
	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) 
	{
		

	}

}
