package Products;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;

@JsonTypeName("health")

public class Weapon extends Product
{
	private int damage;
	private String range;
	/**
	 * 
	 * @param name
	 * @param description
	 * @param price
	 * @param quantity
	 * @param damage
	 * @param range
	 */
	
	public Weapon(@JsonProperty("name") String name,
	        @JsonProperty("description") String description,
	        @JsonProperty("price") double price,
	        @JsonProperty("quantity") int quantity,
	        @JsonProperty("damage") int damage,
	        @JsonProperty("range") String range)
	{
		super(name, description, price, quantity);
		this.damage = damage;
		this.range = range;
	}
	/**
	 * 
	 * @return
	 */
	public int getDamage()
	{
		return damage;
	}
	/**
	 * 
	 * @return
	 */
	public String range()
	{
		return range;
	}
	
	/**
	 * 
	 */
	@Override
	public String toString()
	{
		return super.toString() + "  Damage: " + damage + "  Range: " +  range + "\n";
	}
}
