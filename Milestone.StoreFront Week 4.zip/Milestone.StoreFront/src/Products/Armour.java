package Products;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;

@JsonTypeName("armour")
public class Armour extends Product
{
	private int protection;
	
	/**
	 * 
	 * @param name
	 * @param description
	 * @param price
	 * @param quantity
	 * @param protection
	 */
	public Armour(@JsonProperty("name") String name,
	        @JsonProperty("description") String description,
	        @JsonProperty("price") double price,
	        @JsonProperty("quantity") int quantity,
	        @JsonProperty("property") int protection)
	{
		super(name, description, price, quantity);
		this.protection = protection;
	}
	/**
	 * 
	 * @return
	 */
	public int getProtection()
	{
		return protection;
	}
	/**
	 * 
	 */
	@Override
	public String toString()
	{
		return super.toString() + "  Protection: " + protection + "\n";
	}
	
}
